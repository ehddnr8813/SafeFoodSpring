package com.ssafy.service;

import com.ssafy.vo.User;

public interface UserService {

	String login(String userId, String password);
	
	void signup(User user);

	void delete(String id);
	
	public User searchUser(String id);
	
	public void update(User user);
	
}
