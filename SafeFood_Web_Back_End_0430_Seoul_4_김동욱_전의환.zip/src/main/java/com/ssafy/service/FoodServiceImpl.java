package com.ssafy.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.dao.FoodDao;
import com.ssafy.dao.FoodDaoImpl;
import com.ssafy.util.FoodSaxParser;
import com.ssafy.vo.Food;

public class FoodServiceImpl implements FoodService {
	
	private FoodDao foodDao;
	
	public void setFoodDao(FoodDao foodDao) {
		this.foodDao = foodDao;
	}
	
	@Override
	public Food detailed(int code) throws SQLException {
		return foodDao.searchDetail(code);
	}
	
	
	@Override
	public List<Food> searchAll() throws SQLException {
		return foodDao.searchAll();
	}

	@Override
	public List<Food> searchByName(String name) throws SQLException {
		return foodDao.searchByName(name);
	}

	@Override
	public List<Food> searchByMaker(String maker) throws SQLException {
		return foodDao.searchByMaker(maker);
	}

	@Override
	public Food searchByCode(int code) throws SQLException {
		return foodDao.searchByCode(code);
	}

	@Override
	public List<Food> searchByMaterial(String material) throws SQLException {
		return foodDao.searchByMaterial(material);
	}
	
	@Override
	public void insertFoods() {
		foodDao.insertFoods();
	}
}
