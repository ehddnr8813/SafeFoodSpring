package com.ssafy.service;

import com.ssafy.dao.UserDAO;
import com.ssafy.vo.User;

public class UserServiceImpl implements UserService {

	UserDAO userDao;
	
	public void setUserDao(UserDAO userDao) {
		this.userDao = userDao;
	}

	@Override
	public String login(String id, String pw) {
		return userDao.login(id, pw);
	}

	@Override
	public void signup(User user) {
		userDao.insertUser(user);
	}
	
	@Override
	public void delete(String id) {
		userDao.deleteUser(id);
	}

	@Override
	public User searchUser(String id) {
		return userDao.searchUser(id);
	}

	@Override
	public void update(User user) {
		userDao.updateUser(user);
	}

}
