package com.ssafy.service;

import java.util.List;

import com.ssafy.dao.AllergyHasPersonDAO;

public class AllergyHasPersonServiceImpl implements AllergyHasPersonService {

	AllergyHasPersonDAO allergyhaspersonDao;
	
	public void setAllergyhaspersonDao(AllergyHasPersonDAO allergyhaspersonDao) {
		this.allergyhaspersonDao = allergyhaspersonDao;
	}

	@Override
	public void insertAllergy(String id, String allergy_name) {
		allergyhaspersonDao.insertAllergy(id, allergy_name);
	}

	@Override
	public void deleteAllergy(String id) {
		allergyhaspersonDao.deleteAllergy(id);
	}

	@Override
	public List<String> searchAllergyById(String id) {
		return allergyhaspersonDao.searchAllergyById(id);
	}

}
