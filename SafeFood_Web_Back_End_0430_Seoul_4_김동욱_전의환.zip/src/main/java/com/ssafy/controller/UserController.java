package com.ssafy.controller;


import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.dao.UserDAOImpl;
import com.ssafy.service.UserService;
import com.ssafy.service.AllergyHasPersonService;
import com.ssafy.vo.User;

@RequestMapping("/user")
@Controller
public class UserController {
   
	private UserService userService;
	private AllergyHasPersonService ahpService;

	@Autowired
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@Autowired
	public void setAhpService(AllergyHasPersonService ahpService) {
		this.ahpService = ahpService;
	}
	
	@GetMapping("/index.do")
	public String index() {
		return "redirect:/index.jsp";
	}

	@PostMapping("/login.do")
	public String login(String id, String pw, HttpSession session) {
		String name = userService.login(id, pw);
		if(name != null) {
			session.setAttribute("id", id);
			return "redirect:/index.jsp";
		}
		return "redirect:/index.jsp"; 
	}
	
	@PostMapping("/signup.do") // 회원가입
	public String signup(User user, String[] allergy) {
		userService.signup(user);
		System.out.println(user);
		System.out.println(Arrays.toString(allergy));
		
		// 회원가입 할 때 allergy 에 추가. 
		for(int i = 0; i < allergy.length; i++) {
			ahpService.insertAllergy(user.getId(), allergy[i]);
		}
		return "redirect:/login.jsp";
	}
	
	@GetMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/login.jsp";
	}
	
	// allergy 정보도 같이 삭제해야함.
	@GetMapping("/delete.do")
	public String delete(String id, HttpSession session) {
		ahpService.deleteAllergy(id);
		userService.delete(id);
		session.invalidate();
		return "redirect:/index.jsp";
	}
	
	@GetMapping("/editinfo.do")
	public String editinfo() {
		return "editinfo";
	}
	
	@PostMapping("/update.do") // 회원정보 수정
	public String update(HttpSession session, User user, String[] allergy) {
		// 먼저 알러지에 내 아이디 비우기
		ahpService.deleteAllergy(user.getId());
		userService.update(user);
		
		// 회원수정 할 때 다시 allergy 에 추가. 
		for(int i = 0; i < allergy.length; i++) {
			ahpService.insertAllergy(user.getId(), allergy[i]);
		}
		
		session.setAttribute("id", user.getId());
		session.setAttribute("pw", user.getPw());
		session.setAttribute("name", user.getName());
		session.setAttribute("email", user.getEmail());
		
		// List를 넣는거임.
		session.setAttribute("allergyList", ahpService.searchAllergyById(user.getId()));
		
		return "redirect:/index.jsp";
	}
	
	// 여기서 내 페이지로 가게됨.
	// 내 정보들 가져가야함. session 이용
	@GetMapping("/mypage.do")
	public String myPage(HttpSession session, String id) {
		User user = userService.searchUser(id);
		
		System.out.println("id는 : " + id);
		session.setAttribute("id", id);
		session.setAttribute("pw", user.getPw());
		session.setAttribute("name", user.getName());
		session.setAttribute("email", user.getEmail());
		
		// List를 넣는거임.
		session.setAttribute("allergyList", ahpService.searchAllergyById(id));
		
		return "mypage";
	}
	
	

}
