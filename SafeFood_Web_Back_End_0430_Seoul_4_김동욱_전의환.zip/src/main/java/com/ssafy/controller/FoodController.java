package com.ssafy.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.dao.UserDAOImpl;
import com.ssafy.service.FoodService;
import com.ssafy.service.FoodServiceImpl;
import com.ssafy.vo.Food;
import com.ssafy.vo.User;

@RequestMapping("/food")
@Controller
public class FoodController {

	
	private FoodService foodService;
	
	@Autowired
	public void setFoodService(FoodService foodService) {
		this.foodService = foodService;
	}
	
	
	@GetMapping("/insertFoods.do")
	public String insertFoods() {
		foodService.insertFoods();
		return "redirect:/index.jsp";
	}
	
	@GetMapping({"/selectAll.do","/index.do"})
	public String selectAll(Model model) throws SQLException {
		model.addAttribute("foodList", foodService.searchAll());
		return "index";
	}
	
	@GetMapping("/showdetail.do")
	public String showDetail(Model model, int code) throws SQLException {
		System.out.println("show : " + foodService.searchByCode(code));
		model.addAttribute("food", foodService.searchByCode(code));
		
		return "indexx2";
	}
	
	@PostMapping("/searchBy.do")
	public String searchByName(Model model, String select, String what) throws SQLException {
		System.out.println(select + " " + what);
		if(select.equals("name")) {
			model.addAttribute("foodList", foodService.searchByName(what));
			return "index";
		}else if(select.equals("maker")){
			model.addAttribute("foodList", foodService.searchByMaker(what));
			return "index";
		}
		model.addAttribute("foodList", null);
		return "index";
	}
	
	@GetMapping("/eatFood.do")
	public String eatFood() {
		
		return "index";
	}
/*	@GetMapping("/selectAll.do")
	public String selectAll(RedirectAttributes ra) throws SQLException {
		ra.addFlashAttribute("foodList", foodService.searchAll());
		return "redirect:/food/index.do";
	}
*/
	/*@GetMapping("/getFoodNutritionInfoXML.do")
	public String getFoodNutritionInfoXML() {
		
		return "foodNutritionInfoXML";
	}
	
	@GetMapping("/getFoodInfoXML.do")
	public  String getFoodInfoXML() {
		
	}*/
	
	
	/*public PageInfo search(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        String select = request.getParameter("select");
        String what = request.getParameter("what");
        switch (select) {
		case "code":
			try {
				List<Food> temp1 = new LinkedList<>();
				HttpSession session = request.getSession();
				String cur_id = (String) session.getAttribute("userId");
				UserDAOImpl userMgr = UserDAOImpl.getInstance();
				Food f = foodService.searchByCode(Integer.parseInt(what));
				String allergy = "";
				if(f!=null)temp1.add(f);
				request.setAttribute("foods", temp1);
				int size = userMgr.getAllergy(cur_id).size();
				
				// 내 알러지와 같은 내용 있으면 추가.
				for(int i = 0; i < size; i++) {
					if(f.getMaterial().contains(userMgr.getAllergy(cur_id).get(i))) { 
						allergy += userMgr.getAllergy(cur_id).get(i) + " "; 
					}
				}
				System.out.println(allergy);
				request.setAttribute("allergy", allergy);
						
				
			} catch (NumberFormatException e) {
				request.setAttribute("foods", foodService.searchAll());
				return new PageInfo(true,"indexx.jsp");
			}
			break;
		case "name":
			List<Food> temp2 = new LinkedList<>();
			for (Food food : foodService.searchByName(what)) {
				temp2.add(food);
			}
			request.setAttribute("foods", temp2);
			break;
		case "maker":
			List<Food> temp3 = new LinkedList<>();
			for (Food food : foodService.searchByMaker(what)) {
				temp3.add(food);
			}
			request.setAttribute("foods", temp3);
			break;
		case "material":
			List<Food> temp4 = new LinkedList<>();
			for (Food food : foodService.searchByMaterial(what)) {
				temp4.add(food);
			}
			request.setAttribute("foods", temp4);
			break;
		default:
			request.setAttribute("foods", foodService.searchAll());
			break;
		}
        
        return new PageInfo(true, "foodInfoXML.jsp");
    }*/
	/*public PageInfo searchNutrition(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		int code = Integer.parseInt(request.getParameter("code"));
		List<Food> list = new LinkedList<>();
		list.add(foodService.searchByCode(code));
		HttpSession session = request.getSession(true);
		String id = (String)session.getAttribute("userId");
		if(id!=null) {
			User u = userdao.getUser(id);
			ArrayList<String> aList = new ArrayList<>();
			for(int i=0;i<u.allergyList.size();++i) {
				aList.add(u.allergyList.get(i));
			}
			ArrayList<String> tempList = new ArrayList<>();
			for(int i=0;i<aList.size();++i) {
				if(list.get(0).getMaterial().contains(aList.get(i))) {
					tempList.add(aList.get(i));
				}
			}
			request.setAttribute("allergy", tempList);
		}
		request.setAttribute("foods", list);
		return new PageInfo(true,"foodNutritionInfoXML.jsp");
	}*/
	
	/*public PageInfo detailed(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		int code= Integer.parseInt(request.getParameter("code"));
		request.setAttribute("food", foodService.detailed(code));
		System.out.println(foodService.detailed(code));

		return new PageInfo(true, "foodNutritionInfoXML.jsp");
	}*/
	
}
