package com.ssafy.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.util.FoodSaxParser;
import com.ssafy.vo.Food;

public class FoodDaoImpl implements FoodDao {
	private static FoodDao instance;
	private List<Food> foodList=null;
	
	private SqlSession session;
	
	public void setSession(SqlSession session) {
		this.session = session;
	}
	
	
	// DB에 food 넣기
	@Override
	public void insertFoods() {
		FoodSaxParser parser = new FoodSaxParser();
		List<Food> list = parser.getFoods();
		
		int size = list.size();
		for(int i = 0; i < size; i++) {
			session.insert("food.insertFoods", list.get(i));
		}
		for(int i = 0; i < size; i++) {
			//System.out.println(list.get(i));
		}
		
	}
	
	@Override
	public List<Food> searchAll() throws SQLException{
		//foodList = search();
		return session.selectList("food.selectAll");
	}
	
	/*public void save() throws SQLException{
		FoodSaxParser parser = new FoodSaxParser();
		foodList = parser.getFoods();
		add(foodList);
	}*/
	
	@Override
	public void add(Food food){
		session.insert("food.insert", food);
		return;
	}
	
	@Override
	public Food search(int code) throws SQLException{
		return session.selectOne("food.select", code);
	}
	
	// 상세보기 페이지로 넘기는거.
	@Override
	public Food searchDetail(int code){
		return null;
	}
	
	@Override
	public List<Food> searchByName(String name) throws SQLException{
		return session.selectList("food.selectByName", name);
	}	
	@Override
	public List<Food> searchByMaker(String maker) throws SQLException{
		return session.selectList("food.selectByMaker", maker);
	}

	@Override
	public Food searchByCode(int code) throws SQLException {
		return session.selectOne("food.selectByCode", code);
	}

	@Override
	public List<Food> searchByMaterial(String material) throws SQLException {
		return session.selectList("food.selectByMaterial", material);
	}

}
