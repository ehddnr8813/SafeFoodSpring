package com.ssafy.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ssafy.vo.PersonHasFood;

public class PersonHasFoodDaoImpl implements PersonHasFoodDao {

	@Override
	public void add(String personId, int foodCode) throws SQLException {
	}
	
	@Override
	public boolean updateFP(String personId){
		return false;
	}

	@Override
	public void delete(String personId) throws SQLException {
	}

	@Override
	public PersonHasFood getPF(String personId) throws SQLException {
		return null;
	}

}
