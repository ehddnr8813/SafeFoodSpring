package com.ssafy.dao;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.vo.User;

public class UserDAOImpl implements UserDAO {
	
	SqlSession session;
	
	public void setSession(SqlSession session) {
		this.session = session;
	}

	@Override
	public void insertUser(User user) {
		session.insert("user.insert", user);
	}
	
	@Override
	public void deleteUser(String id) {
		session.delete("user.delete", id);
	}
	
	@Override
	public void updateUser(User user) {
		session.update("user.update", user);
	}
	
	@Override
	public User searchUser(String id) {
		return session.selectOne("user.search", id);
	}
	
	@Override
	public String login(String userId, String password) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("id", userId);
		map.put("pw", password);
		return session.selectOne("user.login", map);
	}
	
	/*@Override
	public List<User> selectUserWithAllergyList(String id) {
		// TODO Auto-generated method stub
		return session.selectOne("director.selectDirectorWithMovieList",id);
	}*/
}
