package com.ssafy.dao;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.vo.User;

public interface UserDAO {

	public void insertUser(User user);
	
	public void deleteUser(String id);
	
	public void updateUser(User user);
	
	public User searchUser(String id);
	
	public String login(String userId, String password);
	
	
}
