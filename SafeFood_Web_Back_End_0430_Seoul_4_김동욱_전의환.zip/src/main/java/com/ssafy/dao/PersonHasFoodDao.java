package com.ssafy.dao;

import java.sql.SQLException;

import com.ssafy.vo.PersonHasFood;

public interface PersonHasFoodDao {

	void add(String personId, int foodCode) throws SQLException;
	
	void delete(String personId) throws SQLException;

	PersonHasFood getPF(String personId) throws SQLException;
	
	public boolean updateFP(String personId);
}
