package com.ssafy.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.vo.Food;

public interface FoodDao {

	List<Food> searchAll() throws SQLException;

	void add(Food food) throws SQLException;

	List<Food> searchByName(String name) throws SQLException;

	List<Food> searchByMaker(String maker) throws SQLException;

	Food searchByCode(int code) throws SQLException;
	
	List<Food> searchByMaterial(String material) throws SQLException;
	
	public Food searchDetail(int code) throws SQLException;

	Food search(int code) throws SQLException;

	void insertFoods();
}