package com.ssafy.dao;

import java.util.List;

public interface AllergyHasPersonDAO {
	// 해당 아이디에 대한 알러지 삽입
	public void insertAllergy(String id, String allergy_name);
	
	// 해당 아이디에 대한 알러지 정보 다 삭제.
	public void deleteAllergy(String id);
	
	// 해당 아이디에 대한 알러지 가져오기
	public List<String> searchAllergyById(String id);
}
