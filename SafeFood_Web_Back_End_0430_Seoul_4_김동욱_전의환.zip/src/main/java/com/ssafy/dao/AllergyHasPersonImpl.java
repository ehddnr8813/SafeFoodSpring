package com.ssafy.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.vo.AllergyHasPerson;

public class AllergyHasPersonImpl implements AllergyHasPersonDAO {

	SqlSession session;
	
	public void setSession(SqlSession session) {
		this.session = session;
	}

	// 얘는 여러번 실행해야됨.
	@Override
	public void insertAllergy(String id, String allergy_name) {
		AllergyHasPerson ahp = new AllergyHasPerson(id, allergy_name);
		session.insert("allergy.insert", ahp);
		
	}
	@Override
	public void deleteAllergy(String id) {
		session.delete("allergy.delete", id);
	}

	@Override
	public List<String> searchAllergyById(String id) {
		return session.selectList("allergy.searchAllergyById", id);
	}

}
