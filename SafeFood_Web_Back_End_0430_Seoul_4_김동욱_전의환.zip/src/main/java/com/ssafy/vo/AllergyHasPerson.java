package com.ssafy.vo;

public class AllergyHasPerson {
	
	private String id;
	private String allergy_name;
	
	public AllergyHasPerson() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AllergyHasPerson(String id, String allergy_name) {
		super();
		this.id = id;
		this.allergy_name = allergy_name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAllergy_name() {
		return allergy_name;
	}
	public void setAllergy_name(String allergy_name) {
		this.allergy_name = allergy_name;
	}
	@Override
	public String toString() {
		return "AllergyHasPerson [id=" + id + ", allergy_name=" + allergy_name + "]";
	}

}
