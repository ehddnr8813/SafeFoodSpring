package com.ssafy.vo;

public class PersonHasFood {
	private String person_id;
	private String food_code;
	private int quantity;
	
	
	
	public PersonHasFood() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PersonHasFood(String person_id, String food_code) {
		this.person_id = person_id;
		this.food_code = food_code;
		quantity=1;
	}
	public String getPerson_id() {
		return person_id;
	}
	public void setPerson_id(String person_id) {
		this.person_id = person_id;
	}
	public String getFood_code() {
		return food_code;
	}
	public void setFood_code(String food_code) {
		this.food_code = food_code;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "PersonHasFood [person_id=" + person_id + ", food_code=" + food_code + ", quantity=" + quantity + "]";
	}
	
}
