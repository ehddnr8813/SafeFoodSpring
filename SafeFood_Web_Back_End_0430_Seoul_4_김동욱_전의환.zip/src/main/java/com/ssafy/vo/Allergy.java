package com.ssafy.vo;

public class Allergy {
	private String allergy_name;
	
}
