package com.dao;

import java.sql.SQLException;

import com.vo.PersonHasFood;

public interface PersonHasFoodDao {

	void add(String personId, int foodCode) throws SQLException;
	
	void delete(String personId) throws SQLException;

	PersonHasFood getPF(String personId) throws SQLException;
}
