package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.ssafy.util.DBUtil;
import com.vo.Food;
import com.vo.PersonHasFood;

public class PersonHasFoodDaoImpl implements PersonHasFoodDao {

	@Override
	public void add(String personId, int foodCode) throws SQLException {
		Connection conn=null;
		PreparedStatement stmt=null;
		String sql="insert into person_has_food values(?, ?, ?)";
		
		try {
			conn= DBUtil.getConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1, personId);
			stmt.setInt(2, foodCode);
			stmt.setInt(3, 1);
			stmt.executeUpdate();

		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
	}
	
	public boolean updateFP(String personId) throws SQLException{
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = "update person_has_food set quantity=quantity+1 where person_id"+personId;

		try {
			conn = DBUtil.getConnection();
			stmt =conn.prepareStatement(sql);
			stmt.setString(1, personId);
			return stmt.executeUpdate()>0;
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
	}
	

	@Override
	public void delete(String personId) throws SQLException {
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = "delete from person_has_food where person_id="+personId;

		try {
			conn = DBUtil.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, personId);
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
	
		}
	}

	@Override
	public PersonHasFood getPF(String personId) throws SQLException {
		
		return null;
	}

}
