package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.util.DBUtil;
import com.vo.User;


public class UserDAO {
	private static UserDAO userMgr;
	private List<User> users;
	
	private UserDAO() {
		users = new ArrayList<>();
	}
	
	public static UserDAO getInstance() {
		if(userMgr == null) userMgr = new UserDAO();
		return userMgr;
	}
	
	// user 가져오기
	public User getUser(String id) throws SQLException, ClassNotFoundException {
		User user = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from person where id=?";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DBUtil.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, id);
			rs = stmt.executeQuery();
			if(rs.next()) {
				user = new User(rs.getString(1), rs.getString(2),rs.getString(3),rs.getString(4));
			}
		}finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return user;
	}
	
	
	// 수정중
	public List<User> getUsers() throws ClassNotFoundException, SQLException {
		ArrayList<User> list = new ArrayList<User>();
		Connection conn = null;
		PreparedStatement stmt = null; // 여기를 프리페어드로 바
		ResultSet rs = null;
		String sql = "select * from person";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DBUtil.getConnection();
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				list.add(new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
			}
			
		}finally { // 각각 try catch
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		
		return list;
	}
	
	
	
	
	// InsertAllergy 추가 해야됨.
	public boolean insertUser(User user) throws SQLException {
		ArrayList<User> list = new ArrayList<User>();
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = "insert into person values(?, ?, ?, ?)";
		String sql2 = "insert into allergy_has_person values(?, ?)";
		
		try {
			//Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DBUtil.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, user.getId());
			stmt.setString(2, user.getPw());
			stmt.setString(3, user.getName());
			stmt.setString(4, user.getEmail());
			//stmt.setString(3, user.getAllergyList());
			stmt.executeUpdate();
			
			// add allergy
			if(user.getAllergyList().size() > 0) {
				System.out.println("size : " + user.getAllergyList().size());
				stmt = conn.prepareStatement(sql2);
				for(int i = 0; i < user.getAllergyList().size(); i++) {
					//System.out.println(user.getAllergyList().get(i));
					stmt.setString(1, user.getAllergyList().get(i));
					stmt.setString(2, user.getId());
					stmt.executeUpdate();
				}
			}
			
			return true;
			
			/*if(rs.next()) {
				list.add(new Dept(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}*/
		}finally { // 각각 try catch
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
	}
	
	// updateAllergy 추가하기
	public boolean updateUser(User user) {
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = "update person set id = ? , pw=?, name=?, email=? where id=?";
		
		// allergy table 수정 sql
		String sql2 = "delete from allergy_has_person where person_id= ?";
		String sql3 = "insert into allergy_has_person values(?, ?)";
		try {
			//Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DBUtil.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, user.getId());
			stmt.setString(2, user.getPw());
			stmt.setString(3, user.getName());
			stmt.setString(4, user.getEmail());
			//stmt.setString(5, user.getAllergyList());
			stmt.setString(5, user.getId());
			stmt.executeUpdate();
			
			stmt = conn.prepareStatement(sql2); // 삭제 먼저
			
			stmt.setString(1, user.getId()); // 아이디 관련 알러지 모두 삭제
			stmt.executeUpdate();
			
			stmt = conn.prepareStatement(sql3);
			for(int i = 0; i < user.getAllergyList().size(); i++) {
				stmt.setString(1, user.getAllergyList().get(i));
				stmt.setString(2, user.getId());
				stmt.executeUpdate();
			}
			
			return true;
			
			/*if(rs.next()) {
				list.add(new Dept(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}*/
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally { // 각각 try catch
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
		
	}
	
	
	// 유저 삭제되면 알러지 정보도 다 같이 삭제
	// deleteAllergy 추가
	public void deleteUser(String id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql2 = "delete from allergy_has_person where person_id = ?";
		String sql = "delete from person where id = ?";
		
		try {
			//Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DBUtil.getConnection();
			stmt = conn.prepareStatement(sql2);
			stmt.setString(1, id);
			stmt.executeUpdate();
			
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, id);
			stmt.executeUpdate();
			//return stmt.executeLargeUpdate(sql) > 0;
			
			/*if(rs.next()) {
				list.add(new Dept(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}*/
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally { // 각각 try catch
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
	}
	
	public List<String> getAllergy(String id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> list = new ArrayList<String>();
		String sql = "select * from allergy_has_person "
				+ "where person_id = ?";
		
		try {
			//Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DBUtil.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, id);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				list.add(rs.getString(1));
				System.out.println("rs : " + rs.getString(1));
			}
			
			
			//return stmt.executeLargeUpdate(sql) > 0;
			
			/*if(rs.next()) {
				list.add(new Dept(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}*/
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally { // 각각 try catch
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return list;
	}
	
	
}













