package com.dao;

import java.awt.print.Book;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.util.DBUtil;
import com.util.FoodSaxParser;
import com.vo.Food;

public class FoodDaoImpl implements FoodDao {
	private static FoodDao instance;
	private List<Food> foodList=null;
	
	private FoodDaoImpl() {
		FoodSaxParser parser = new FoodSaxParser();
		foodList = parser.getFoods();
	}
	
	public static FoodDao getInstance() {
		if(instance == null) instance = new FoodDaoImpl();
		return instance;
	}
	
	@Override
	public List<Food> searchAll() throws SQLException{
		foodList = search();
		return foodList;
	}
	
	public void save() throws SQLException{
		FoodSaxParser parser = new FoodSaxParser();
		foodList = parser.getFoods();
		add(foodList);
	}
	
	@Override
	public void add(List<Food> food) throws SQLException {
		Connection conn=null;
		PreparedStatement stmt=null;
		PreparedStatement stmt2=null;
		String sql="insert into food values(?, ?, ?, ?, ?)";
		String sql2="insert into food_nutrition values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			conn= DBUtil.getConnection();
			stmt=conn.prepareStatement(sql);
			for(Food f : food){
				stmt.setInt(1,  f.getCode());
				stmt.setString(2, f.getName());
				stmt.setString(3, f.getMaker());
				stmt.setString(4, f.getMaterial());
				stmt.setString(5, f.getImg());
				stmt.executeUpdate();
			}
			
			stmt2=conn.prepareStatement(sql2);
			for(Food f : food){
				stmt2.setString(1,  f.getName());
				stmt2.setDouble(2, f.getSupportpereat());
				stmt2.setDouble(3, f.getCalory());
				stmt2.setDouble(4, f.getCarbo());
				stmt2.setDouble(5, f.getProtein());
				stmt2.setDouble(6, f.getFat());
				stmt2.setDouble(7, f.getSugar());
				stmt2.setDouble(8, f.getNatrium());
				stmt2.setDouble(9, f.getChole());
				stmt2.setDouble(10, f.getFattyacid());
				stmt2.setDouble(11, f.getTransfat());
				stmt2.executeUpdate();
			}

		} finally {
			DBUtil.close(stmt);
		//	DBUtil.close(stmt2);
			DBUtil.close(conn);
		}
	}
	public List<Food> search() throws SQLException{
		ArrayList<Food> fList= new ArrayList<Food>();
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql="select code, food_name, food_maker, food_material, food_image from food ";
		
		try {
			conn= DBUtil.getConnection();
			stmt=conn.prepareStatement(sql);
			rs=stmt.executeQuery();
			
			while(rs.next()){
				fList.add(new Food(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
			}
			
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return fList;
	}
	
	public Food searchDetail(int code) throws SQLException{
		Food f= null;
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql="select * from food f, food_nutrition n where f.code=? and f.food_name=n.f_name";
		
		try {
			conn= DBUtil.getConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, code);
			rs=stmt.executeQuery();
			while(rs.next()){
				f=new Food(code, rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getDouble(7), rs.getDouble(8), rs.getDouble(9), rs.getDouble(10), rs.getDouble(11), rs.getDouble(12), rs.getDouble(13), rs.getDouble(14), rs.getDouble(15), rs.getDouble(16));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return f;
	}
	
	
	@Override
	public List<Food> searchByName(String name) throws SQLException{
		ArrayList<Food> fList= new ArrayList<Food>();
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql="select code, food_name, food_maker, food_material, food_image from food where food_name like concat('%',?,'%')";
		
		try {
			conn= DBUtil.getConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1,  name);
			rs=stmt.executeQuery();
			
			while(rs.next()){
				fList.add(new Food(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
				System.out.println(rs.getInt(1));
			}
			
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return fList;
	}	
	@Override
	public List<Food> searchByMaker(String maker) throws SQLException{
		ArrayList<Food> fList= new ArrayList<Food>();
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql="select code, food_name, food_maker, food_material, food_image from food where food_maker like concat('%',?,'%')";
		
		try {
			conn= DBUtil.getConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1,  maker);
			rs=stmt.executeQuery();
			
			while(rs.next()){
				fList.add(new Food(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
			}
			
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return fList;

	}

	@Override
	public Food searchByCode(int code) throws SQLException {
		Food food= new Food();
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql="select code, food_name, food_maker, food_material, food_image from food where code=?";
		
		try {
			conn= DBUtil.getConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, code);
			rs=stmt.executeQuery();
			
			while(rs.next()){
				food.setCode(rs.getInt(1));
				food.setName(rs.getString(2));
				food.setMaker(rs.getString(3));
				food.setMaterial(rs.getString(4));
				food.setImg(rs.getString(5));
			}
			
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}

		return food;
	}

	@Override
	public List<Food> searchByMaterial(String material) throws SQLException {
		ArrayList<Food> fList= new ArrayList<Food>();
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sql="select code, food_name, food_maker, food_material, allergy from food where food_materail like concat('%',?,'%')";
		
		try {
			conn= DBUtil.getConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1, material);
			rs=stmt.executeQuery();
			
			while(rs.next()){
				fList.add(new Food(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
			}
			
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}

		return fList;
		
	}
	
}
