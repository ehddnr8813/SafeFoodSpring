package com.service;

import java.sql.SQLException;
import java.util.List;

import com.vo.Food;

public interface FoodService {

	List<Food> searchAll() throws SQLException;
	
	List<Food> searchByName(String name) throws SQLException;
	
	List<Food> searchByMaker(String maker) throws SQLException;
	
	Food searchByCode(int code) throws SQLException;
	
	List<Food> searchByMaterial(String material) throws SQLException;
	
	public void getSave() throws SQLException;
	
	Food detailed(int code) throws SQLException;
}