package com.service;

import java.sql.SQLException;
import java.util.List;

import com.dao.FoodDao;
import com.dao.FoodDaoImpl;
import com.util.FoodSaxParser;
import com.vo.Food;

public class FoodServiceImpl implements FoodService {
	
	private static FoodService instance;
	private FoodDao foodDao;
	
	private FoodServiceImpl() {
		foodDao = FoodDaoImpl.getInstance();
	}
	
	public static FoodService getInstance() {
		if(instance == null) instance = new FoodServiceImpl();
		return instance;
	}

	public void getSave() throws SQLException{
		foodDao.save();
	}
	
	@Override
	public Food detailed(int code) throws SQLException {
		return foodDao.searchDetail(code);
	}
	
	
	@Override
	public List<Food> searchAll() throws SQLException {
		return foodDao.searchAll();
	}

	@Override
	public List<Food> searchByName(String name) throws SQLException {
		return foodDao.searchByName(name);
	}

	@Override
	public List<Food> searchByMaker(String maker) throws SQLException {
		return foodDao.searchByMaker(maker);
	}

	@Override
	public Food searchByCode(int code) throws SQLException {
		return foodDao.searchByCode(code);
	}

	@Override
	public List<Food> searchByMaterial(String material) throws SQLException {
		return foodDao.searchByMaterial(material);
	}
	
}
