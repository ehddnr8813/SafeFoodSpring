package com.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.vo.*;
import com.dao.*;

public class CheckService {
	private static CheckService checkService;
	public static CheckService getInstance() {
		if (checkService == null) checkService = new CheckService();
		return checkService;
	}

	/**
	 * 아이디, 비밀번호 유효성 검사
	 *
	 * @param id
	 * @param pw
	 * @return
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public boolean checkAccount(String id, String pw) throws ClassNotFoundException, SQLException {
		UserDAO userMgr = UserDAO.getInstance();
		List<User> list = userMgr.getUsers();
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).id.equals(id) 
					&& list.get(i).pw.equals(pw)) {
				return true;
			}
		}
		return false;
	}
}
