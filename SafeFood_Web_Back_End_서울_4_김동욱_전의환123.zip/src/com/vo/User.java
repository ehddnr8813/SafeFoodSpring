package com.vo;
import java.util.ArrayList;

public class User {
	public String id;
	public String pw;
	public String name;
	public String email;
	public ArrayList<String> allergyList;
	
	public User(String id, String pw, String name, String email) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
	}
	public User(String id, String pw, String name, String email,
			ArrayList<String> list) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
		this.allergyList = new ArrayList<String>();
		for(int i = 0; i < list.size(); i++) {
			allergyList.add(list.get(i));
		}
		for(int i = 0; i < allergyList.size(); i++) {
			System.out.println(allergyList.get(i));
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public ArrayList<String> getAllergyList() {
		return allergyList;
	}
	public void setAllergyList(ArrayList<String> allergyList) {
		this.allergyList = allergyList;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", pw=" + pw + ", name=" + name + ", email=" + email + ", allergyList=" + allergyList
				+ "]";
	}
	
}
