package com.controller;


import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.SQLException;
import java.util.HashMap;

import com.dao.UserDAO;
import com.service.*;
import com.vo.PageInfo;
import com.vo.User;

public class UserController {
    private CheckService checkService = CheckService.getInstance();
    private static UserDAO userDao = UserDAO.getInstance();
    private static UserController userController;
    public static UserController getInstance() {
        if (userController == null) userController = new UserController();
        return userController;
    }

    /**
     * 로그인
     *
     * @param request
     * @param response
     * @return
     * @throws SQLException 
     * @throws ClassNotFoundException 
     */
    public PageInfo login(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
        String id = request.getParameter("id");
        String pw = request.getParameter("pw");
        String check = request.getParameter("idSave");

        HashMap<String, String> errorMessages = new HashMap<>();
        if (id == null || id.trim().length() == 0) {
            System.out.println("아이디가 입력되지 않았습니다.");
            errorMessages.put("idError", "아이디가 입력되지 않았습니다.");
        }
        if (pw == null || pw.trim().length() == 0) {
            System.out.println("비밀번호가 입력되지 않았습니다.");
            errorMessages.put("pwError", "비밀번호가 입력되지 않았습니다.");
        }
        if (errorMessages.size() > 0) {
            request.setAttribute("errorMessages", errorMessages);
            return new PageInfo(true, "login.jsp");
        }

        checkService = new CheckService();
        boolean flag = checkService.checkAccount(id, pw);
        
        if (flag) {
            HttpSession session = request.getSession();
            User tmp = userDao.getUser(id);
            System.out.println(userDao.getAllergy(id).size());
            session.setAttribute("userId", tmp.id);
            session.setAttribute("userPw", tmp.pw);
            session.setAttribute("userEmail", tmp.email);
            session.setAttribute("userAllergy", userDao.getAllergy(id));
            session.setAttribute("user", tmp);

            if (check != null && check.equals("on")) {
                Cookie c = new Cookie("userId", id);
                response.addCookie(c);
            }
            return new PageInfo("index.jsp");
        } else return new PageInfo(true, "login.jsp");
    }

    /**
     * 로그아웃
     *
     * @param request
     * @param response
     * @return
     */
    public PageInfo logout(HttpServletRequest request, HttpServletResponse response) {
        request.getSession().invalidate();
        return new PageInfo("index.jsp");
    }

}
