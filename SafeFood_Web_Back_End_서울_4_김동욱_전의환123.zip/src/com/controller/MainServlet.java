package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UserDAO;
import com.vo.PageInfo;
import com.vo.User;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/main.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private FoodController foodController = FoodController.getInstance();
	private UserController userService = UserController.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}
	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		PageInfo page = null;
		System.out.println(action);
		try {
			switch (action) {
				case "login": page = userService.login(request, response); break;
				case "list" : page= foodController.saved(request, response); break;
				case "logout": page = userService.logout(request, response); break;
				case "detail": page=foodController.detailed(request, response);break;
				case "delete": page = delete(request, response); break;
				case "signup": page = signup(request, response); break;
				case "enroll": page = enroll(request, response); break;
				case "mypage": page = mypage(request, response); break;
				case "editinfo": page = editinfo(request, response); break;
				case "getFoodInfoXML": page = foodController.getFoodInfoXML(request, response);break;
				case "getFoodNutritionInfoXML": page = foodController.getFoodNutritionInfoXML(request, response);break;
				case "search": page = foodController.search(request, response);break;
				case "searchNutrition": page = foodController.searchNutrition(request, response);break;
				case "findpw": page = findPw(request, response);break;
				case "searchPw": page = searchPw(request, response);break;
			}
			if (page.isForward()) {
				System.out.println(page.getUrl());
				request.getRequestDispatcher(page.getUrl()).forward(request, response);
				return;
			} else {
				response.sendRedirect(page.getUrl());
				return;
			}
		} catch (Exception e) {
			request.setAttribute("errorMsg", e.getMessage());
			request.getRequestDispatcher("/error.jsp").forward(request, response);
			return;
		}
		
	}
	
	private PageInfo searchPw(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		
		String id = request.getParameter("id");
		UserDAO userMgr = UserDAO.getInstance();
		
		User user = userMgr.getUser(id);
		if(user == null) {
			request.setAttribute("pw", "존재하지 않는 아이디 입니다.");
		}else {
			request.setAttribute("pw", "비밀번호 : " + user.getPw());
		}
		
		return new PageInfo(true, "findresult.jsp");
	}

	private PageInfo findPw(HttpServletRequest request, HttpServletResponse response) {
		return new PageInfo(false, "findpw.jsp");
	}

	public PageInfo signup(HttpServletRequest request, HttpServletResponse response) {
        return new PageInfo(false, "signup.jsp");
    }
	
	public PageInfo enroll(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
        String id = request.getParameter("id");
        String pw = request.getParameter("pw");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String[] allergyList = request.getParameterValues("allergy");
        
        ArrayList<String> list = new ArrayList<String>();
        if(allergyList != null) {
        	for(int i = 0; i < allergyList.length; i++) {
        		list.add(allergyList[i]);
        	}
        }
        
        
        UserDAO userMgr = UserDAO.getInstance();
		userMgr.insertUser(new User(id, pw, name, email, list));
		
		HttpSession session = request.getSession(true);
		session.setAttribute("users", userMgr.getUsers());
		
        return new PageInfo(false, "login.jsp");
	}
	
	public PageInfo mypage(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		String id = request.getParameter("id");
		UserDAO userMgr = UserDAO.getInstance();
		User findUser = userMgr.getUser(id);
		if(findUser == null) return new PageInfo(false, "login.jsp");
		
		HttpSession session = request.getSession(true);
		session.setAttribute("user", findUser);
		return new PageInfo(false, "mypage.jsp");
	}
	
	public PageInfo editinfo(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String[] allergyList = request.getParameterValues("allergy");
		ArrayList<String> list = new ArrayList<String>();
		if(allergyList != null) {
        	for(int i = 0; i < allergyList.length; i++) {
        		list.add(allergyList[i]);
        	}
        }
		
		UserDAO userMgr = UserDAO.getInstance();
		userMgr.updateUser(new User(id, pw, name, email, list));
		User tmp = userMgr.getUser(id);
		HttpSession session = request.getSession(true);
		session.setAttribute("userId", tmp.id);
        session.setAttribute("userPw", tmp.pw);
        session.setAttribute("userEmail", tmp.email);
        session.setAttribute("userAllergy", list);
		session.setAttribute("user", tmp);
		return new PageInfo(false, "index.jsp");
	}
	
	public PageInfo delete(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession(true);
		String id = (String)session.getAttribute("userId");
		UserDAO userMgr = UserDAO.getInstance();
		userMgr.deleteUser(id);
		request.getSession().invalidate();
		return new PageInfo(false, "main.html");
	}

}
