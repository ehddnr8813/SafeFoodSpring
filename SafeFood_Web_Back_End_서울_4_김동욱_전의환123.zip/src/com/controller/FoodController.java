package com.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.dao.UserDAO;
import com.service.FoodService;
import com.service.FoodServiceImpl;
import com.vo.Food;
import com.vo.PageInfo;
import com.vo.User;

public class FoodController {

	private FoodService foodService = FoodServiceImpl.getInstance();
	private UserDAO userdao = UserDAO.getInstance();
	
	private static FoodController instance = new FoodController();
	public static FoodController getInstance() {
		if(instance==null) instance = new FoodController();
		return instance;
	}
	public PageInfo getFoodNutritionInfoXML(HttpServletRequest request,HttpServletResponse response) throws SQLException {
		request.setAttribute("foods", foodService.searchAll());
		return new PageInfo(true,"foodNutritionInfoXML.jsp");
	}
	
	public  PageInfo getFoodInfoXML(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		request.setAttribute("foods", foodService.searchAll());
		return new PageInfo(true,"foodInfoXML.jsp");
	}

	
	
	public  PageInfo saved(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		foodService.getSave();
		return new PageInfo(false,"login.jsp");
	}
	public PageInfo search(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        String select = request.getParameter("select");
        String what = request.getParameter("what");
        switch (select) {
		case "code":
			try {
				List<Food> temp1 = new LinkedList<>();
				HttpSession session = request.getSession();
				String cur_id = (String) session.getAttribute("userId");
				UserDAO userMgr = UserDAO.getInstance();
				Food f = foodService.searchByCode(Integer.parseInt(what));
				String allergy = "";
				if(f!=null)temp1.add(f);
				request.setAttribute("foods", temp1);
				int size = userMgr.getAllergy(cur_id).size();
				
				// 내 알러지와 같은 내용 있으면 추가.
				for(int i = 0; i < size; i++) {
					if(f.getMaterial().contains(userMgr.getAllergy(cur_id).get(i))) { 
						allergy += userMgr.getAllergy(cur_id).get(i) + " "; 
					}
				}
				System.out.println(allergy);
				request.setAttribute("allergy", allergy);
						
				
			} catch (NumberFormatException e) {
				request.setAttribute("foods", foodService.searchAll());
				return new PageInfo(true,"indexx.jsp");
			}
			break;
		case "name":
			List<Food> temp2 = new LinkedList<>();
			for (Food food : foodService.searchByName(what)) {
				temp2.add(food);
			}
			request.setAttribute("foods", temp2);
			break;
		case "maker":
			List<Food> temp3 = new LinkedList<>();
			for (Food food : foodService.searchByMaker(what)) {
				temp3.add(food);
			}
			request.setAttribute("foods", temp3);
			break;
		case "material":
			List<Food> temp4 = new LinkedList<>();
			for (Food food : foodService.searchByMaterial(what)) {
				temp4.add(food);
			}
			request.setAttribute("foods", temp4);
			break;
		default:
			request.setAttribute("foods", foodService.searchAll());
			break;
		}
        
        return new PageInfo(true, "foodInfoXML.jsp");
    }
	public PageInfo searchNutrition(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		int code = Integer.parseInt(request.getParameter("code"));
		List<Food> list = new LinkedList<>();
		list.add(foodService.searchByCode(code));
		HttpSession session = request.getSession(true);
		String id = (String)session.getAttribute("userId");
		if(id!=null) {
			User u = userdao.getUser(id);
			ArrayList<String> aList = new ArrayList<>();
			for(int i=0;i<u.allergyList.size();++i) {
				aList.add(u.allergyList.get(i));
			}
			ArrayList<String> tempList = new ArrayList<>();
			for(int i=0;i<aList.size();++i) {
				if(list.get(0).getMaterial().contains(aList.get(i))) {
					tempList.add(aList.get(i));
				}
			}
			request.setAttribute("allergy", tempList);
		}
		request.setAttribute("foods", list);
		return new PageInfo(true,"foodNutritionInfoXML.jsp");
	}
	public PageInfo detailed(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		int code= Integer.parseInt(request.getParameter("code"));
		request.setAttribute("food", foodService.detailed(code));
		System.out.println(foodService.detailed(code));

		return new PageInfo(true, "foodNutritionInfoXML.jsp");
	}
	
}
